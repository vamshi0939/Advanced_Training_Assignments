package com.vamshi.training;

public abstract class Instrument {
	public abstract void play();
}
